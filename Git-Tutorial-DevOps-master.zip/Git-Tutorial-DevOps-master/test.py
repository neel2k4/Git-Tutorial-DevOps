#my first python code. Time to learn data science technologies like PowerBI and Tableau and Python
#my first change to compare
